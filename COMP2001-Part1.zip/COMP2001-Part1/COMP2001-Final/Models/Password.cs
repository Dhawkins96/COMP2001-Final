﻿using System;
using System.Collections.Generic;

#nullable disable

namespace COMP2001_Final
{
    public partial class Password
    {
        public int PasswordId { get; set; }
        public int UserId { get; set; }
        public string UserPassword { get; set; }
        public DateTime PassChanged { get; set; }

        public virtual User User { get; set; }
    }
}
